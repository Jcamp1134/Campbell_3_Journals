package Xeleom_Campbell;


class Blocked {

	public static boolean[][] Blocked;

	public static boolean[][] getblocked() {

		return Blocked;

	}

};
